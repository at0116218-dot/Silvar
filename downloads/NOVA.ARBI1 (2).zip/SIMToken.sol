// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/access/AccessControl.sol";

contract SIMToken is ERC20, AccessControl {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");
    uint256 public maxCap;

    constructor(uint256 _initialSupply, uint256 _maxCap, address multisig) ERC20("SIM Token", "SIM") {
        _setupRole(DEFAULT_ADMIN_ROLE, multisig);
        _setupRole(MINTER_ROLE, multisig);
        maxCap = _maxCap;
        _mint(multisig, _initialSupply);
    }

    function mint(address to, uint256 amount) external onlyRole(MINTER_ROLE) {
        require(totalSupply() + amount <= maxCap, "cap exceeded");
        _mint(to, amount);
    }

    function setCap(uint256 newCap) external onlyRole(DEFAULT_ADMIN_ROLE) {
        maxCap = newCap;
    }
}
