#!/usr/bin/env python3
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import datetime, os, json

app = FastAPI(title="Eleanor Core - Backend Stub")

DATA_DIR = os.path.dirname(__file__)
LEDGER = os.path.join(DATA_DIR, "ledger.json")
USERS_DB = os.path.join(DATA_DIR, "users.json")
if not os.path.exists(LEDGER):
    with open(LEDGER, "w", encoding="utf-8") as f:
        json.dump([], f)
if not os.path.exists(USERS_DB):
    with open(USERS_DB, "w", encoding="utf-8") as f:
        json.dump({}, f)

class RegisterIn(BaseModel):
    username: str
    wallet: str

@app.get("/health")
def health():
    with open(USERS_DB, encoding="utf-8") as f:
        users = json.load(f)
    total_sim = sum(int(u.get("sim_balance",0)) for u in users.values())
    return {"status":"ok","users_count":len(users),"sim_supply":total_sim}

@app.post("/register")
def register(payload: RegisterIn):
    with open(USERS_DB, encoding="utf-8") as f:
        users = json.load(f)
    if payload.username in users:
        raise HTTPException(status_code=400, detail="username exists")
    now = datetime.datetime.utcnow().isoformat()
    users[payload.username] = {"wallet": payload.wallet, "created_at": now, "sim_balance": 100}
    with open(USERS_DB, "w", encoding="utf-8") as f:
        json.dump(users, f, ensure_ascii=False, indent=2)
    # append ledger
    with open(LEDGER, "r+", encoding="utf-8") as f:
        ledger = json.load(f)
        ledger.append({"ts":now, "type":"airdrop", "wallet":payload.wallet, "amount":100})
        f.seek(0); json.dump(ledger, f, ensure_ascii=False, indent=2)
    return {"status":"ok","granted":100}
