USERS_THRESHOLD = 15_000_000
INITIAL_CAP = 3_000_000_000
USER_AIRDROP = 100
TARGET_PER_USER = 200
REWARD_PER_EVENT = 33

def simulate(days, new_users_per_day, security_events_per_day):
    users = 0
    supply = 0
    for d in range(days):
        users += new_users_per_day
        # update cap
        current_cap = users * TARGET_PER_USER if users >= USERS_THRESHOLD else INITIAL_CAP
        # airdrops
        potential = new_users_per_day * USER_AIRDROP
        give = min(potential, max(0, current_cap - supply))
        supply += give
        # security events
        events = security_events_per_day
        mint_from_events = events * REWARD_PER_EVENT
        if supply + mint_from_events > current_cap:
            mint_from_events = max(0, current_cap - supply)
        supply += mint_from_events
    return users, supply

if __name__ == "__main__":
    users, supply = simulate(365, 10000, 50)
    print(f"After 365 days: users={users}, supply={supply}")
