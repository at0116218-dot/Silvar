#!/usr/bin/env bash
set -euo pipefail
echo "This is a lightweight installer stub. Run manual setup according to README."
