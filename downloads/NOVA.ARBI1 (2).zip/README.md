# Eleanor NOVA.ARBI1 - Backup Package

This archive contains a conservative PoC package and documentation for the Eleanor platform backup named NOVA.ARBI1.

Files included:
- blueprint.md          : Architectural blueprint (Arabic + English notes)
- bib_config.json       : Configuration for bib agents (2 sample agents included)
- sim_model.py          : Supply/tokenomics simulator (Python)
- SIMToken.sol          : Example ERC-20 token contract (Solidity)
- backend/main.py       : FastAPI backend stub (simple file-based DB)
- install_and_run.sh    : Minimal installer stub for Termux / Linux

How to use:
1. Inspect blueprint.md and bib_config.json.
2. For local testing, install Python 3.9+, create a venv, `pip install fastapi uvicorn`.
3. Run backend: `uvicorn backend.main:app --host 127.0.0.1 --port 8000`
4. Use sim_model.py to test tokenomics: `python sim_model.py`

Security notice: This package is a PoC and educational. Do not use on production without audits, security hardening, and legal compliance.
